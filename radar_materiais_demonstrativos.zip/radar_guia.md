# Radar de licitações com IA

**Demonstração com dados fictícios e interface própria.**

Execução simulada com deduplicação e revisão humana.

## Fluxo
1. Receber fontes e critérios
2. Coletar itens de exemplo
3. Eliminar duplicidades
4. Classificar aderência
5. Revisar os documentos
6. Registrar próximas ações

## Critérios e contexto
- Relatório demonstrativo: 28/10/2026, 08h00. Entradas: 4. Duplicidades: 1. Únicas: 3. Aderentes: 1. Fora do escopo: 1. Em revisão: 1. Nenhuma submissão realizada.
- Configuração ilustrativa de tarefa: dias úteis às 08h00, America/Sao_Paulo; checagem semanal de certidões. É uma representação criada para demonstrar a rotina; não comprova que uma tarefa foi agendada ou executada em uma conta real.
- Prompt de exemplo: compare o objeto com o escopo informado, preserve a fonte e o prazo, sinalize dúvidas, agrupe duplicidades e gere próximas ações para revisão humana.